<html>
<footer>
    <p>&copy; <?php echo date("Y"); ?> Buy Bright. All rights reserved.</p>
</footer>
</body>
</html>
